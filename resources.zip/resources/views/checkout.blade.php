<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Checkout') }}
        </h2>
    </x-slot>

	<!-- UIkit CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.9.4/dist/css/uikit.min.css" />

    <!-- UIkit JS -->
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.9.4/dist/js/uikit.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.9.4/dist/js/uikit-icons.min.js"></script>
	<style>
		@media print {
			nav {
				display: none;
			}

			header {
				display: none;
			}

			.uk-card-title {
				display: none;
			}

			.uk-button {
				display: none;
			}

			.uk-alert-warning {
				display: none;
			}
		}
	</style>

	<div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
			<div class="uk-card uk-card-body" style="color:rgb(0, 0, 0);">
				<div class="uk-card-title">
					<h3 class="uk-card-title" style="color:rgb(0, 0, 0);">Checkout</h3>
				</div>
				<div>
					<button class="uk-button uk-button-primary uk-text-bold"><a style="color:rgb(255, 255, 255);" href="{{ url('/dashboard') }}">Back</a></button>
				</div>
				@if ($errors->any())
				<div class="uk-alert-danger" uk-alert>
					<a class="uk-alert-close" uk-close></a>
					<p>There were some problems with your input</p>
					<ul>
						@foreach ($errors->all() as $error)
						<li>{{ $error }}</li>
						@endforeach
					</ul>
				</div>
				@endif
				<hr>
				<form action="{{ url('/dashboard' . '/' . $ticket->id) . '/checkoutfinal' }}">
					{!! csrf_field() !!}
					<fieldset class="uk-fieldset">
						<legend class="uk-legend">Ticket Information</legend>
						<input type="hidden" name="id" id="id" value="{{ $ticket->id }}" id="id" />
						<input type="hidden" class="uk-input uk-form-width-large" type="text" name="licence_plate" placeholder="Licence Plate" id="licence_plate"
							value="{{ $ticket->licence_plate }}">
						<input type="hidden" class="uk-input uk-form-width-large" type="number" name="mobile" placeholder="Mobile" id="mobile"
							value="{{ $ticket->mobile }}">
						<input type="hidden" class="uk-input uk-form-width-large" type="text" name="vehicle" placeholder="Vehicle" id="vehicle"
							value="{{ $ticket->vehicle }}">
						<input type="hidden" class="uk-input uk-form-width-large" type="text" name="status" placeholder="Status" id="status"
							value="{{ $ticket->status+=1 }}">
						<input type="hidden" class="uk-input uk-form-width-large" type="text" name="price" placeholder="Price" id="price"
							value="{{ $price }}">
						<div class="uk-margin">
							<div class="uk-text-large">Price: MVR{{ $price }}</div>
							<div class="uk-text-large">Vehicle: {{ $ticket->vehicle }}</div>
							<div class="uk-text-large">Mobile: {{ $ticket->mobile }}</div>
							<div class="uk-text-large">Entry: {{ $ticket->created_at }}</div>
							<div class="uk-text-large">Exit: {{ $dt }}</div>
							<div class="uk-text-large">Total Time: {{ $diff }}</div>
							<hr>
							<div class="uk-alert-warning" uk-alert>
								<a class="uk-alert-close" uk-close></a>
								<div class="uk-text-medium">Warning: once checked out you cannot edit the ticket anymore. If you want to undo your action you will have to ask your database admin.</div>
							</div>

						</div>
						<div class="uk-margin uk-align-center">
							<button type="submit" value="Update" class="uk-button uk-button-primary">Checkout</button>
						</div>
					</fieldset>
				</form>
				<button onclick="printPage()" class="uk-button uk-button-primary">Print</button>
			</div>
		</div>
	</div>

	<script defer>
		function printPage() {
			window.print();
		}
	</script>
</x-app-layout>