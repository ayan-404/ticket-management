<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    <!-- UIkit CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.9.4/dist/css/uikit.min.css" />

    <!-- UIkit JS -->
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.9.4/dist/js/uikit.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.9.4/dist/js/uikit-icons.min.js"></script>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div>
                <button class="uk-button uk-button-primary uk-text-bold"><a style="color:rgb(255, 255, 255);"
                        href="{{ url('/dashboard/create') }}">Add
                        Ticket</a></button>
            </div>
            @if ($message = Session::get('success'))
            <div class="uk-alert-success" uk-alert>
                <a class="uk-alert-close" uk-close></a>
                <p>{{ $message }}</p>
            </div>
            @endif
            <table class="uk-table uk-table-divider">
                <thead>
                    <tr>
                        <th class="text-gray-900">No.</th>
                        <th class="text-gray-900">Licence Plate</th>
                        <th class="text-gray-900">Mobile</th>
                        <th class="text-gray-900">Vehicle</th>
                        <th class="text-gray-900">Price</th>
                        <th  width="220px">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($tickets as $item)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ $item->licence_plate }}</td>
                        <td>{{ $item->mobile }}</td>
                        <td>{{ $item->vehicle }}</td>
                        @if (!$item->status == 0)
                        <td>MVR{{ $item->price }}</td>
                        @else
                        <td width="220px">This ticket has not been checked out yet!</td>
                        @endif
                        @if ($item->status == 0)
                        <td width="220px">
                            <a class="uk-button uk-button-primary uk-button-small" href="{{ url('/dashboard' . '/' . $item->id)  . '/edit' }}">Edit</a>
                            <a class="uk-button uk-button-danger uk-button-small" href="{{ url('/dashboard' . '/' . $item->id) . '/checkout' }}">Checkout</a>
                        </td>
                        @else
                        <td width="220px">This ticket has been checked out</td>
                        @endif
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</x-app-layout>
