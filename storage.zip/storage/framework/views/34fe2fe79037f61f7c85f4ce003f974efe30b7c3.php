<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <!-- UIkit CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.9.4/dist/css/uikit.min.css" />

    <!-- UIkit JS -->
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.9.4/dist/js/uikit.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.9.4/dist/js/uikit-icons.min.js"></script>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div>
                <button class="uk-button uk-button-primary uk-text-bold"><a style="color:rgb(255, 255, 255);"
                        href="<?php echo e(url('/dashboard/create')); ?>">Add
                        Ticket</a></button>
            </div>
            <?php if($message = Session::get('success')): ?>
            <div class="uk-alert-success" uk-alert>
                <a class="uk-alert-close" uk-close></a>
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
            <table class="uk-table uk-table-divider">
                <thead>
                    <tr>
                        <th class="text-gray-900">No.</th>
                        <th class="text-gray-900">Licence Plate</th>
                        <th class="text-gray-900">Mobile</th>
                        <th class="text-gray-900">Vehicle</th>
                        <th class="text-gray-900">Price</th>
                        <th  width="220px">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->licence_plate); ?></td>
                        <td><?php echo e($item->mobile); ?></td>
                        <td><?php echo e($item->vehicle); ?></td>
                        <?php if(!$item->status == 0): ?>
                        <td>MVR<?php echo e($item->price); ?></td>
                        <?php else: ?>
                        <td width="220px">This ticket has not been checked out yet!</td>
                        <?php endif; ?>
                        <?php if($item->status == 0): ?>
                        <td width="220px">
                            <a class="uk-button uk-button-primary uk-button-small" href="<?php echo e(url('/dashboard' . '/' . $item->id)  . '/edit'); ?>">Edit</a>
                            <a class="uk-button uk-button-danger uk-button-small" href="<?php echo e(url('/dashboard' . '/' . $item->id) . '/checkout'); ?>">Checkout</a>
                        </td>
                        <?php else: ?>
                        <td width="220px">This ticket has been checked out</td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/laravelworkspace/ticketSystem/resources/views/dashboard.blade.php ENDPATH**/ ?>