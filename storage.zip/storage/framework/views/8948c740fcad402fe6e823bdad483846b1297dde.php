<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Edit')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

	<!-- UIkit CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.9.4/dist/css/uikit.min.css" />

    <!-- UIkit JS -->
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.9.4/dist/js/uikit.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.9.4/dist/js/uikit-icons.min.js"></script>

	<div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
			<div class="uk-card uk-card-body" style="color:rgb(0, 0, 0);">
				<div class="uk-card-title">
					<h3 class="uk-card-title" style="color:rgb(0, 0, 0);">Edit Ticket</h3>
				</div>
				<div>
					<button class="uk-button uk-button-primary uk-text-bold"><a style="color:rgb(255, 255, 255);" href="<?php echo e(url('/dashboard')); ?>">Back</a></button>
				</div>
				<?php if($errors->any()): ?>
				<div class="uk-alert-danger" uk-alert>
					<a class="uk-alert-close" uk-close></a>
					<p>There were some problems with your input</p>
					<ul>
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</div>
				<?php endif; ?>
				<hr>
				<form action="<?php echo e(url('/dashboard' . '/' . $ticket->id)); ?>">
					<?php echo csrf_field(); ?>

					<fieldset class="uk-fieldset">
						<legend class="uk-legend">Please fill this form correctly to edit the ticket</legend>
						<input type="hidden" name="id" id="id" value="<?php echo e($ticket->id); ?>" id="id" />
						<div class="uk-margin">
							<input class="uk-input uk-form-width-large" type="text" name="licence_plate" placeholder="Licence Plate" id="licence_plate"
								value="<?php echo e($ticket->licence_plate); ?>">
						</div>
						<div class="uk-margin">
							<input class="uk-input uk-form-width-large" type="number" name="mobile" placeholder="Mobile" id="mobile"
								value="<?php echo e($ticket->mobile); ?>">
						</div>
						<div class="uk-margin">
							<input class="uk-input uk-form-width-large" type="text" name="vehicle" placeholder="Vehicle" id="vehicle"
								value="<?php echo e($ticket->vehicle); ?>">
						</div>
						<div class="uk-margin uk-align-center">
							<button type="submit" value="Update" class="uk-button uk-button-primary">Submit</button>
						</div>
					</fieldset>
				</form>
			</div>
		</div>
	</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /var/www/html/laravelworkspace/ticketSystem/resources/views/edit.blade.php ENDPATH**/ ?>